#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_set>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

vector<string> tokenize(const string& text) {
    vector<string> tokens;
    string word;
    istringstream stream(text);
    while (stream >> word) {
        word.erase(remove_if(word.begin(), word.end(), ::ispunct), word.end());
        transform(word.begin(), word.end(), word.begin(), ::tolower);
        tokens.push_back(word);
    }
    return tokens;
}

string readFile(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file: " << filename << endl;
        return "";
    }
    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

double calculateSimilarity(const vector<string>& tokens1, const vector<string>& tokens2) {
    unordered_set<string> set1(tokens1.begin(), tokens1.end());
    unordered_set<string> set2(tokens2.begin(), tokens2.end());
    int common = 0;

    for (const auto& word : set1) {
        if (set2.count(word)) common++;
    }

    int total = set1.size() + set2.size() - common;
    return total == 0 ? 0.0 : static_cast<double>(common) / total * 100;
}

int main() {
    string file1 = "file1.txt";
    string file2 = "file2.txt";

    string text1 = readFile(file1);
    string text2 = readFile(file2);

    vector<string> tokens1 = tokenize(text1);
    vector<string> tokens2 = tokenize(text2);

    double similarity = calculateSimilarity(tokens1, tokens2);

    cout << "Plagiarism Similarity Score: " << similarity << "%\n";

    return 0;
}
